
public class Supervisor extends ILeaveRequestHandler{


	public Supervisor(ILeaveRequestHandler nextHandler){
		super(nextHandler);
	}
	
	@Override
	public void handleRequest(LeaveRequest leaveRequest) {

		if(leaveRequest.getNoOfLeaves() >= 1 && leaveRequest.getNoOfLeaves() <3){
			System.out.println("Supervisor ");
		}
		else
			super.handleRequest(leaveRequest);
	}

}
