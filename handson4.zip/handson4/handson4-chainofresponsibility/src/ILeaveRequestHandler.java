
public abstract class ILeaveRequestHandler {

	protected ILeaveRequestHandler nextHandler;
	
	public ILeaveRequestHandler(ILeaveRequestHandler nextHandler){
		this.nextHandler = nextHandler;
	}
	public void handleRequest(LeaveRequest leaveRequest){
		if(nextHandler != null){
			nextHandler.handleRequest(leaveRequest);
		}
	}
}
