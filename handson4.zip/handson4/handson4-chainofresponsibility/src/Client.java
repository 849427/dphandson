
public class Client {
	
	public static void main(String[] args) {
		
		LeaveRequest leaveRequest = new LeaveRequest();
		leaveRequest.setEmployeeName("Mohit Sajwan");
		leaveRequest.setNoOfLeaves(6);
		
		Chain chain = new Chain();
		chain.handleRequest(leaveRequest);
		
	}
}
