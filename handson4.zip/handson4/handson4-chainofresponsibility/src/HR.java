
public class HR extends ILeaveRequestHandler{

	
	public HR(ILeaveRequestHandler nextHandler){
		super(nextHandler);
	}
	
	@Override
	public void handleRequest(LeaveRequest leaveRequest) {
		
		if(leaveRequest.getNoOfLeaves() > 5){
			System.out.println("HR ");
		}
		else
			super.handleRequest(leaveRequest);
	}

}
