public class Chain 
{ 
ILeaveRequestHandler chain; 
  
public Chain(){ 
    buildChain(); 
} 
  
private void buildChain(){ 
    chain = new HR(new ProjectManager(new Supervisor(null))); 
} 
  
public void handleRequest(LeaveRequest leaveRequest) { 
    chain.handleRequest(leaveRequest); 
} 
  
} 