
public class ProjectManager extends ILeaveRequestHandler{


	public ProjectManager(ILeaveRequestHandler nextHandler){
		super(nextHandler);
	}
	
	@Override
	public void handleRequest(LeaveRequest leaveRequest) {
		if(leaveRequest.getNoOfLeaves() >= 3 && leaveRequest.getNoOfLeaves() <=5){
			System.out.println("Project Manager ");
		}
		else
			super.handleRequest(leaveRequest);		
	}

}
