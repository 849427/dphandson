
public class RedmiNote7 implements IPhone {

	@Override
	public String GetPhonePart1() {
		return "Display redmi";
	}

	@Override
	public double GetPart1Cost() {
		return 500;
	}

}
