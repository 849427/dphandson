
public interface IPhone {

	String GetPhonePart1();
	
	double GetPart1Cost();
}
