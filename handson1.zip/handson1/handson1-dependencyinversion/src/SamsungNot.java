
public class SamsungNot implements IPhone {

	@Override
	public String GetPhonePart1() {
		return "Display samsung";
	}

	@Override
	public double GetPart1Cost() {
		return 500;
	}

}
