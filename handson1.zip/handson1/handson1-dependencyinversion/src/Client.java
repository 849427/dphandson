
public class Client {

	public static void main(String[] args) {

		ProcessPhoneRepair phoneRepair = new ProcessPhoneRepair();
		IPhone samsung = new SamsungNot();
		IPhone redmi = new RedmiNote7();
		phoneRepair.RepairSteps(samsung);
		phoneRepair.RepairSteps(redmi);
		
	}

}
