package handson1;

public interface IAccessoryRepair {
	void ProcessAccessoryRepair(String accessoryType);

}
