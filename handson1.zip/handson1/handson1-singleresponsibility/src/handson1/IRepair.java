package handson1;

public interface IRepair {
	
	void ProcessRepair(String modelName);
}
