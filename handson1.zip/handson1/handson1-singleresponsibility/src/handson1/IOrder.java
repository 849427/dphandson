package handson1;

public interface IOrder {

	void ProcessOrder(String modelName);
}
