package handson1;

public class PhoneAccessoryRepair implements IAccessoryRepair {

	@Override
	public void ProcessAccessoryRepair(String accessoryType) {

		System.out.println(accessoryType + " repair accepted");
	}

}
