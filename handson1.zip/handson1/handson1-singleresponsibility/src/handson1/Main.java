package handson1;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to our site. Would you like to order or repair?");
		String processOption = sc.nextLine().toLowerCase().trim();
		String productDetail = "";
		
		switch(processOption){
		case "order":
			System.out.println("please provide the phone model name");
			productDetail = sc.nextLine().trim();
			IOrder phoneOrder = new PhoneOrder();
			phoneOrder.ProcessOrder(productDetail);
			break;
			
		case"repair":
			System.out.println("Is it the phone or the accessory that you want to be repaired?");
			String productType = sc.nextLine().toLowerCase();
			if(productType.equals("phone")){
				System.out.println("please provide the phone model name");
				productDetail = sc.nextLine().trim();
				IRepair phoneRepair = new PhoneRepair();
				phoneRepair.ProcessRepair(productDetail);
			}
			else{
				System.out.println("please provide the accessory detail, like headphone, tempered glass");
				productDetail = sc.nextLine().trim();
				IAccessoryRepair accessoryRepair = new PhoneAccessoryRepair();
				accessoryRepair.ProcessAccessoryRepair(productDetail);
			}
			break;
			
		default:
			break;
		}
	}

}
