package handson1;

public class PhoneRepair implements IRepair {

	@Override
	public void ProcessRepair(String modelName) {
		
		System.out.println(modelName + " repair accepted");
	}

}
