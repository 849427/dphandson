
public class MercedesTyre extends Tyre {

	public void createTyre(){
		System.out.println("Mercedes tyre created.");
	}
}
