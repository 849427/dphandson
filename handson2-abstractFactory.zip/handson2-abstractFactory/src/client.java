
public class client {

	public static void main(String[] args) {
		
		Factory mercedes = FactoryProducer.getFactory("Mercedes");
		Factory audi = FactoryProducer.getFactory("audi");
		
		Headlight mercedeshl = mercedes.makeHeadlight();
		Tyre mercedest = mercedes.makeTyre();
		
		Headlight audihl = audi.makeHeadlight();
		Tyre audit = audi.makeTyre();
		
		
		audihl.createHeadlight();
		audit.createTyre();
		
		mercedeshl.createHeadlight();
		mercedest.createTyre();
		
	}

}
