
public class AudiHeadlight extends Headlight {

	public void createHeadlight(){
		System.out.println("Audi headlight created.");
	}
}
