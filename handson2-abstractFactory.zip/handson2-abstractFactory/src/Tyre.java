
public abstract class Tyre {

	public abstract void createTyre();

	
}
