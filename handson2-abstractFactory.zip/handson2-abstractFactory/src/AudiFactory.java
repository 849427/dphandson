
public class AudiFactory extends Factory {

	@Override
	public Headlight makeHeadlight() {
		return new AudiHeadlight();
	}

	@Override
	public Tyre makeTyre() {
		return new AudiTyre();
	}

}
