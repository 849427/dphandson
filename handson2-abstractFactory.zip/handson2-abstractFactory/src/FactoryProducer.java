
public class FactoryProducer {
	
	public static Factory getFactory(String choice)
	{
		if(choice.equalsIgnoreCase("MERCEDES")){
			return new MercedesFactory();
		}
		else if (choice.equalsIgnoreCase("AUDI")){
			return new AudiFactory();
		}
		return null;
	}

	

	
}
