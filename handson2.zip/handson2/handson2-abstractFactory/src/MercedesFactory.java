
public class MercedesFactory extends Factory {
	
	@Override
	public Headlight makeHeadlight() {
		return new MercedesHeadlight();
	}

	@Override
	public Tyre makeTyre() {
		return new MercedesTyre();
	}
	
	
}
