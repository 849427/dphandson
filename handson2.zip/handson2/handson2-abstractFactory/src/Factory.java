
public abstract class Factory {

	public  abstract Headlight makeHeadlight();
	public abstract Tyre makeTyre();
}
