
public class AudiTyre extends Tyre {

	public void createTyre(){
		System.out.println("Audi tyre created.");
	}
}
