
public class MercedesHeadlight extends Headlight {
		
	public void createHeadlight(){
		System.out.println("Mercedes headlight created.");
	}
}
