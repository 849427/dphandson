
public interface IUser {
	
	public void recieveMessage(String msg);
	
	public void sendMessage(String msg);
}
