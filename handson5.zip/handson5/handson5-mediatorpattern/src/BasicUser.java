
public class BasicUser implements IUser {

	private ChatMediator chat;
	
	public BasicUser(ChatMediator chat){
		this.chat = chat;
	}
	
	@Override
	public void recieveMessage(String msg) {
		System.out.println(msg);
	}

	@Override
	public void sendMessage(String msg) {
		chat.sendMessage(msg,this);
	}

}
