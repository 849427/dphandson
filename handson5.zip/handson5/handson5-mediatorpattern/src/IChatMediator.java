import java.util.ArrayList;

public interface IChatMediator {
	
	ArrayList<IUser> users = new ArrayList<>();

	public void addUser(IUser user);
	
	public void sendMessage(String msg,IUser user);
}
