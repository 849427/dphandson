
public class PremiumUser implements IUser {

	private ChatMediator chat;
	
	public PremiumUser(ChatMediator chat){
		this.chat = chat;
	}
	
	@Override
	public void recieveMessage(String msg) {
		System.out.println(msg);
	}

	@Override
	public void sendMessage(String msg) {
		chat.sendMessage(msg,this);
	}

}
