
public class ChatMediator implements IChatMediator {
	
	@Override
	public void addUser(IUser user) {
		users.add(user);
	}

	@Override
	public void sendMessage(String msg,IUser user) {
		for(IUser u : users){
			if(u != user){
				u.recieveMessage(msg);
			}
		}

	}

}
