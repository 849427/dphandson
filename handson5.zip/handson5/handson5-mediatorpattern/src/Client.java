
public class Client {

	public static void main(String[] args) {

		ChatMediator chat = new ChatMediator();
		BasicUser mohit = new BasicUser(chat);
		PremiumUser mohit1 = new PremiumUser(chat);
		BasicUser mohit2 = new BasicUser(chat);
		chat.addUser(mohit1);
		chat.addUser(mohit);
		chat.addUser(mohit2);
		mohit.sendMessage("Hello");
		
		
	}

}
