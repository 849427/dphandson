

public class Test {
	
	public void whenConvertingMPHToKMPH_thenSuccessfullyConverted() { 
	Movable bugattiVeyron = new BugattiVeyron(); 
	MovableAdapter bugattiVeyronAdapter = new MovableAdapterImpl(bugattiVeyron); 
	if(bugattiVeyronAdapter.getSpeed() == 431.30312)
		{
		System.out.println(true);
		}
	else
		System.out.println(false);
	}
	
	public void whenConvertingUSDToEURO_thenSuccessfullyConverted() { 
		Movable bugattiVeyron = new BugattiVeyron(); 
		MovableAdapter bugattiVeyronAdapter = new MovableAdapterImpl(bugattiVeyron); 
		if(bugattiVeyronAdapter.getPrice() == 182.00)
			{
			System.out.println(true);
			}
		else
			System.out.println(false);
		}
	
	
	public static void main(String[] args) {
		Test test = new Test();
		test.whenConvertingMPHToKMPH_thenSuccessfullyConverted();
		test.whenConvertingUSDToEURO_thenSuccessfullyConverted();
	}

}
