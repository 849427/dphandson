public class BugattiVeyron implements Movable { 
	 
	public double getSpeed() { 
		return 268; 
		} 
	public double getPrice(){
		return 200;
	}
	}